export const adminLogin = async(req,res)=>{
    res.render("admin/adminLogin")
}
export const adminDash = async(req,res)=>{
    res.render("admin/adminDash")
}
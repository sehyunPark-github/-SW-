export const deleteProgram = async(req,res)=>{
    console.log("deleteProgram")
    res.send("delete")
}
export const editProgram = async(req,res)=>{
    console.log("editProgram")
}
export const reserveProgram = async(req,res)=>{
    console.log("reserveProgram")
}
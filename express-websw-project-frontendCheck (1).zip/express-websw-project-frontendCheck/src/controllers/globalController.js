export const home = async(req,res)=>{
    res.render("home")
}
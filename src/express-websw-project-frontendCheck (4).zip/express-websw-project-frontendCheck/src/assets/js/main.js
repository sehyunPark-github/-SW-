import "../scss/styles.scss"

import "./partials/programUpload.js"
import "./user.js"

import "./partials/videoHide.js"
import "./partials/slide.js"
import "./partials/reservation.js"
import "./partials/reservation.js"
import "./partials/interactive.js"
import "./partials/dropdown.js"
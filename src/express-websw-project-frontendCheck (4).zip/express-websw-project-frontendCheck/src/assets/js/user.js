const userDataInput = document.getElementById("myUserData")
if(userDataInput){
    console.log(userDataInput.value)
}
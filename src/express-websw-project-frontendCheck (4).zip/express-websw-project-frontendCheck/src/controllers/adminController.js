export const adminDash = async(req,res)=>{
    res.render("admin/adminDash")
}
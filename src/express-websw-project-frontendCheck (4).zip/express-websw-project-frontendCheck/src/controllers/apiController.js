export const deleteProgram = async(req,res)=>{
    console.log("deleteProgram")
    res.send("delete")
}
export const editProgram = async(req,res)=>{
    console.log("editProgram")
}
export const reserveProgram = async(req,res)=>{
    console.log("reserveProgram")
}

//todo : 모든 프로그램명  가져오는 api